# PR Pintra

Aplikasi Android untuk mencatat pekerjaan rumah (PR) sekolah, lengkap dengan **alarm deadline**.

## Fitur

- Tambah PR: nama tugas, mata pelajaran, dan tanggal deadline (pilih lewat kalender)
- **Alarm otomatis** untuk setiap PR:
  - **H-1 pukul 18.00** → "Besok deadline"
  - **Hari deadline pukul 07.00** → "Hari ini deadline"
  - Kalau PR baru ditambahkan untuk hari ini dan jam 07.00 sudah lewat, alarm langsung berbunyi beberapa detik kemudian
  - Alarm dibatalkan otomatis kalau PR dicentang selesai atau dihapus
  - Alarm dijadwalkan ulang otomatis setelah HP restart
- Centang PR yang sudah selesai, hapus PR, penanda "Hari ini!" dan "Terlambat!"
- Semua data tersimpan di HP (tanpa internet)

## Cara membuat APK lewat GitHub (cukup dari HP)

1. Buka github.com, login, lalu buat repository baru (misalnya `pr-pintra`).
2. Di repository itu pilih **Add file → Create new file**. Pada kolom nama file ketik persis:
   `.github/workflows/build-apk.yml`
   lalu tempel isi file `build-apk.yml` (ada di dalam zip ini, folder `.github/workflows/`). Tekan **Commit changes**.
3. Pilih **Add file → Upload files**, lalu upload file **zip ini** (tanpa diekstrak). Tekan **Commit changes**.
4. Buka tab **Actions**. Tunggu proses "Build APK PR Pintra" selesai (sekitar 3–6 menit, centang hijau).
5. Unduh APK di salah satu tempat ini:
   - halaman utama repository → **Releases** → `PR-Pintra.apk`, atau
   - Actions → klik run terakhir → bagian **Artifacts** → `PR-Pintra-APK`.
6. Buka file APK di HP, izinkan "Install dari sumber ini" kalau diminta, lalu install.

Kalau kamu punya komputer, cukup upload semua isi folder proyek ini ke repository (workflow ikut ter-upload), tidak perlu langkah 2.

## Setelah install

- Saat pertama dibuka, **izinkan notifikasi** supaya alarm bisa muncul.
- Jika alarm tidak bunyi di HP tertentu (Xiaomi, Oppo, Vivo, dll.), buka Pengaturan → Aplikasi → PR Pintra → izinkan **Mulai otomatis (Autostart)** dan atur penggunaan baterai ke **Tanpa batasan**.

## Info teknis

- Bahasa: Kotlin, minimum Android 7.0 (API 24)
- Alarm memakai `AlarmManager.setAlarmClock` (tepat waktu, tidak butuh izin exact alarm)
- Build: Gradle 8.5, Android Gradle Plugin 8.2.2, Java 17
- APK ditandatangani dengan `app/debug.keystore` (kunci debug biasa, sengaja ikut di repo) supaya versi baru bisa menimpa versi lama tanpa uninstall. Untuk rilis ke Play Store, buat keystore sendiri dan jangan simpan di repo publik.
- Logo ada di `logo/ic_launcher_512.png`
