package com.prpintra.app

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var store: TaskStore
    private var tasks = mutableListOf<Task>()
    private var pickedDeadline = 0L
    private val dateFormat = SimpleDateFormat("d MMM yyyy", Locale("id", "ID"))

    private lateinit var inputName: EditText
    private lateinit var inputSubject: EditText
    private lateinit var inputDeadline: EditText
    private lateinit var listContainer: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var totalCount: TextView
    private lateinit var doneCount: TextView

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(
                    this,
                    "Izin notifikasi ditolak, alarm tidak bisa muncul. Aktifkan di Pengaturan HP.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = TaskStore(this)
        tasks = store.load()

        inputName = findViewById(R.id.inputName)
        inputSubject = findViewById(R.id.inputSubject)
        inputDeadline = findViewById(R.id.inputDeadline)
        listContainer = findViewById(R.id.listContainer)
        emptyText = findViewById(R.id.emptyText)
        totalCount = findViewById(R.id.totalCount)
        doneCount = findViewById(R.id.doneCount)

        NotificationHelper.ensureChannel(this)
        requestNotificationPermission()

        inputDeadline.setOnClickListener { showDatePicker() }
        findViewById<View>(R.id.buttonAdd).setOnClickListener { addTask() }

        render()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        if (pickedDeadline > 0) cal.timeInMillis = pickedDeadline

        val dialog = DatePickerDialog(
            this,
            { _, year, month, day ->
                val chosen = Calendar.getInstance().apply {
                    set(year, month, day, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                pickedDeadline = chosen.timeInMillis
                inputDeadline.setText(dateFormat.format(chosen.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        dialog.datePicker.minDate = DateUtil.startOfDay(System.currentTimeMillis())
        dialog.show()
    }

    private fun addTask() {
        val name = inputName.text.toString().trim()
        val subject = inputSubject.text.toString().trim()

        if (name.isEmpty()) {
            inputName.error = "Isi nama tugas dulu ya"
            inputName.requestFocus()
            return
        }
        if (pickedDeadline == 0L) {
            Toast.makeText(this, "Pilih tanggal deadline dulu ya", Toast.LENGTH_SHORT).show()
            showDatePicker()
            return
        }

        requestNotificationPermission()

        val task = Task(
            id = store.nextId(),
            name = name,
            subject = if (subject.isEmpty()) "-" else subject,
            deadlineMillis = pickedDeadline,
            done = false
        )
        tasks.add(task)
        store.save(tasks)
        AlarmScheduler.schedule(this, task, fireNowIfPast = true)

        inputName.text.clear()
        inputSubject.text.clear()
        inputDeadline.text.clear()
        pickedDeadline = 0L
        currentFocus?.clearFocus()

        Toast.makeText(this, "PR ditambahkan, alarm deadline aktif ⏰", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun render() {
        listContainer.removeAllViews()

        val sorted = tasks.sortedWith(compareBy<Task>({ it.done }, { it.deadlineMillis }))
        emptyText.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE
        totalCount.text = tasks.size.toString()
        doneCount.text = tasks.count { it.done }.toString()

        val today = DateUtil.startOfDay(System.currentTimeMillis())

        for (task in sorted) {
            val row = layoutInflater.inflate(R.layout.item_task, listContainer, false)
            val check = row.findViewById<CheckBox>(R.id.taskCheck)
            val title = row.findViewById<TextView>(R.id.taskName)
            val meta = row.findViewById<TextView>(R.id.taskMeta)
            val delete = row.findViewById<TextView>(R.id.taskDelete)

            title.text = task.name
            check.isChecked = task.done

            var metaText = "${task.subject}  •  Deadline: ${dateFormat.format(task.deadlineMillis)}"
            var metaColor = ContextCompat.getColor(this, R.color.muted)
            if (!task.done) {
                if (task.deadlineMillis < today) {
                    metaText += "  •  Terlambat!"
                    metaColor = ContextCompat.getColor(this, R.color.danger)
                } else if (task.deadlineMillis == today) {
                    metaText += "  •  Hari ini!"
                    metaColor = ContextCompat.getColor(this, R.color.warn)
                }
            }
            meta.text = metaText
            meta.setTextColor(metaColor)

            if (task.done) {
                title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                title.alpha = 0.5f
            } else {
                title.paintFlags = title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                title.alpha = 1f
            }

            check.setOnClickListener {
                task.done = check.isChecked
                store.save(tasks)
                if (task.done) {
                    AlarmScheduler.cancel(this, task)
                } else {
                    AlarmScheduler.schedule(this, task, fireNowIfPast = false)
                }
                render()
            }

            delete.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Hapus tugas?")
                    .setMessage("\"${task.name}\" akan dihapus beserta alarmnya.")
                    .setPositiveButton("Hapus") { _, _ ->
                        AlarmScheduler.cancel(this, task)
                        tasks.removeAll { it.id == task.id }
                        store.save(tasks)
                        render()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }

            listContainer.addView(row)
        }
    }
}
