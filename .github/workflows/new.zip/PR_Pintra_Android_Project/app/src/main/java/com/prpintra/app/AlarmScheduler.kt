package com.prpintra.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/**
 * Menjadwalkan alarm untuk setiap tugas:
 *  - H-1 pukul 18.00  -> "Besok deadline"
 *  - Hari H pukul 07.00 -> "Hari ini deadline"
 *
 * Memakai setAlarmClock sehingga alarm tetap bunyi tepat waktu (termasuk saat
 * HP dalam mode hemat daya) dan tidak butuh izin "exact alarm" khusus.
 */
object AlarmScheduler {

    const val EXTRA_ID = "task_id"
    const val EXTRA_NAME = "task_name"
    const val EXTRA_SUBJECT = "task_subject"
    const val EXTRA_KIND = "kind"

    const val KIND_TODAY = 0
    const val KIND_TOMORROW = 1

    private const val HOUR_DAY_OF = 7
    private const val HOUR_DAY_BEFORE = 18

    /**
     * @param fireNowIfPast jika true dan deadline adalah hari ini tetapi jam 07.00
     * sudah lewat, alarm dibunyikan beberapa detik lagi (dipakai saat tugas baru ditambah).
     */
    fun schedule(context: Context, task: Task, fireNowIfPast: Boolean) {
        if (task.done) return
        val now = System.currentTimeMillis()

        val dayBefore = DateUtil.at(task.deadlineMillis, -1, HOUR_DAY_BEFORE)
        val dayOf = DateUtil.at(task.deadlineMillis, 0, HOUR_DAY_OF)

        if (dayBefore > now) {
            setAlarm(context, task, KIND_TOMORROW, dayBefore)
        }
        if (dayOf > now) {
            setAlarm(context, task, KIND_TODAY, dayOf)
        } else if (fireNowIfPast && task.deadlineMillis == DateUtil.startOfDay(now)) {
            setAlarm(context, task, KIND_TODAY, now + 5_000L)
        }
    }

    fun cancel(context: Context, task: Task) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (kind in intArrayOf(KIND_TODAY, KIND_TOMORROW)) {
            val pi = PendingIntent.getBroadcast(
                context,
                requestCode(task.id, kind),
                Intent(context, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pi != null) {
                am.cancel(pi)
                pi.cancel()
            }
        }
    }

    fun requestCode(taskId: Int, kind: Int): Int = taskId * 2 + kind

    private fun setAlarm(context: Context, task: Task, kind: Int, triggerAt: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ID, task.id)
            putExtra(EXTRA_NAME, task.name)
            putExtra(EXTRA_SUBJECT, task.subject)
            putExtra(EXTRA_KIND, kind)
        }
        val operation = PendingIntent.getBroadcast(
            context,
            requestCode(task.id, kind),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showIntent), operation)
    }
}
