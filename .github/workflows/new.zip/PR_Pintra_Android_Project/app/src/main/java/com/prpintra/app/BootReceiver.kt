package com.prpintra.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menjadwalkan ulang semua alarm setelah HP dinyalakan ulang atau aplikasi diperbarui. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            TaskStore(context).load().forEach { task ->
                AlarmScheduler.schedule(context, task, fireNowIfPast = false)
            }
        }
    }
}
