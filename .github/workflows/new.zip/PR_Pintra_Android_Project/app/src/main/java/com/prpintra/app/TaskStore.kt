package com.prpintra.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan daftar tugas di perangkat (SharedPreferences, format JSON). */
class TaskStore(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences("pr_pintra", Context.MODE_PRIVATE)

    fun load(): MutableList<Task> {
        val list = mutableListOf<Task>()
        try {
            val arr = JSONArray(prefs.getString(KEY_TASKS, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Task(
                        id = o.getInt("id"),
                        name = o.getString("name"),
                        subject = o.optString("subject", "-"),
                        deadlineMillis = o.getLong("deadline"),
                        done = o.optBoolean("done", false)
                    )
                )
            }
        } catch (e: Exception) {
            // data rusak: mulai dari daftar kosong
        }
        return list
    }

    fun save(tasks: List<Task>) {
        val arr = JSONArray()
        for (t in tasks) {
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("name", t.name)
                    .put("subject", t.subject)
                    .put("deadline", t.deadlineMillis)
                    .put("done", t.done)
            )
        }
        prefs.edit().putString(KEY_TASKS, arr.toString()).apply()
    }

    fun nextId(): Int {
        val id = prefs.getInt(KEY_NEXT_ID, 1)
        prefs.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }

    companion object {
        private const val KEY_TASKS = "tasks"
        private const val KEY_NEXT_ID = "next_id"
    }
}
