package com.prpintra.app

import java.util.Calendar

data class Task(
    val id: Int,
    val name: String,
    val subject: String,
    /** Awal hari (00:00) dari tanggal deadline, dalam milidetik. */
    val deadlineMillis: Long,
    var done: Boolean
)

object DateUtil {
    fun startOfDay(millis: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = millis
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** Waktu [hour]:00 pada hari deadline digeser [dayOffset] hari. */
    fun at(deadlineMillis: Long, dayOffset: Int, hour: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = deadlineMillis
        c.add(Calendar.DAY_OF_MONTH, dayOffset)
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
}
